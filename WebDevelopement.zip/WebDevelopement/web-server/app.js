require('dotenv').config()
const prompt = require('prompt');
const express = require('express');
const app = express();

prompt.start();
const port = process.env.PORT;
const host = process.env.HOST;
const user = process.env.USER;
const uid = process.env.USERID;
const upass = process.env.USERPASS;

app.get("/",(req,res)=>{
    res.send("my server created successfully")
});

prompt.get(['userid', 'userpass'], function (err, result) {
           
    if(uid==result.userid && upass==result.userpass){
        app.listen(port,()=>{
            console.log(`Login User Is:${user}`);
            console.log(`Server get started on ${host}:${port}`)
        })
    }else{
        console.log('Wrong Crendential , You Are Not Valid User');
    }
  });

