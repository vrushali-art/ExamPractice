
const data = require('./arithmatic');
const pro = require('./product');

// console.log(data.addition(500,300));
// console.log(data.addition(850,260));
// console.log(data.subtraction(850,260));
// console.log(data.multiplication(23,2));
// console.log(data.division(850,10));
// console.log(data.msg);

let productObj= new pro.Product(101,"Mouse",500,"Hp");
productObj.productDetails();