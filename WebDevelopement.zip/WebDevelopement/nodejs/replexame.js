console.log("Welcome You All In Node REPl Environment");
let num1=100, num2=400;
num1+num2
let msg="Welcome", myname="Panchashil Wankhede";
msg+myname
msg+myname

function greeting(){
console.log("How Are You All");
}
greeting()