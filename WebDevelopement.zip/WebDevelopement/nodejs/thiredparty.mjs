
import chalk from 'chalk';
import validator from 'validator';
import chalkAnimation from 'chalk-animation';

const error = chalk.bold.red;
const success = chalk.bold.green;

console.log(chalk.bold.red("Hello EveryOne"));
console.log(chalk.bgBlue.red("Hello EveryOne"));
console.log(chalk.bold.blue("Welcome You"),chalk.italic.red("Anshul"));
console.log(error("this is error"));
console.log(success("You done it successfully !"));

console.log("============================");
let msg = "";
console.log(validator.isEmpty(msg));

let myemail="abc@gmail.com";
console.log(validator.isEmail(myemail));
console.log("============");

const rainbow = chalkAnimation.rainbow('Lorem ipsum dolor sit amet');

setTimeout(()=>{
    rainbow.stop();
},3000)