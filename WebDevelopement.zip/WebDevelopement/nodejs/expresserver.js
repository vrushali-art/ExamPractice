require('dotenv').config();
const express = require('express');
const app = express();

const port = process.env.PORT;
const host = process.env.HOST;
const user = process.env.USER;

app.get("/",(req,res)=>{
    // res.send("this is simple get request for home");
    res.sendFile(__dirname+"/index.html");
  });
app.get("/home",(req,res)=>{
//   res.send("this is simple get request for home");
res.sendFile(__dirname+"/index.html");
});
app.get("/about",(req,res)=>{
    // res.send("this is simple get request for About");
    res.sendFile(__dirname+"/about.html");
  });
  app.get("/service",(req,res)=>{
    // res.send("this is simple get request for Service");
    res.sendFile(__dirname+"/service.html");
  });
  app.get("/contact",(req,res)=>{
    // res.send("this is simple get request for Contact");
    res.sendFile(__dirname+"/contact.html");
  });
app.listen(port,()=>{
    console.log(`Login User Is:${user}`);
    console.log(`server get started on ${host}:${port}`)
})