let addition = (num1,num2)=>{
    return num1+num2
}
let subtraction = (num1,num2)=>{
    return num1-num2
}
let multiplication = (num1,num2)=>{
    return num1*num2
}
let division = (num1,num2)=>{
    return num1/num2
}
let msg = "Welcome You All In Nodejs Session";
// console.log(addition(20,62));
// console.log(subtraction(80,62));
// console.log(multiplication(5,6));
// console.log(division(4250,62));
module.exports = {
    addition,multiplication,division,subtraction,msg
}