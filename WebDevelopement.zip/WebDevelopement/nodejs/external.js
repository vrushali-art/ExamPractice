function areaOfCircle(radius){
   return 3.14*radius**2;
}