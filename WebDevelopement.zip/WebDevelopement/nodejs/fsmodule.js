const fs = require('fs');

// writting file synchronously
// fs.writeFileSync("writeFile.text","Hello My Dear friend,where are you");
// read file data synchronously 
// let data =fs.readFileSync("./writeFile.text","utf8",);
// console.log(data);
// append data in file synchronously
// fs.appendFileSync("./writeFile.text","I am in Pune Maharashtra");

// reading file data asynchronously 
fs.readFile("./writeFile.text","utf8",(error,data)=>{
    // console.log(data);
    // write file asynchronously
    fs.writeFile("writeFileAsyn.text",data,()=>{
        console.log("data write successfully");
    })
});
