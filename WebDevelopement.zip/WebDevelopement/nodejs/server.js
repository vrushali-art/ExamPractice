require('dotenv').config();
const http = require('http');
const fs = require('fs');
const prompt = require('prompt');

prompt.start();
const port = process.env.PORT;
const host = process.env.HOST;
const user = process.env.USER;
const uid = process.env.USERID;
const upass = process.env.PASSWORD;

const server = http.createServer((req,res)=>{
    // res.write("Server  Created Successfully");
    // res.end();
    if(req.url=="/" || req.url=="/home"){
        // res.write("This is My Index Page");
        // res.end();
        res.writeHead(200,{"content-type":"text/html"});
     let data = fs.createReadStream("./index.html","utf8");
     data.pipe(res);
    }
  
    if(req.url=="/about"){
    //     res.write("This is My About Page");
    //  res.end();
    res.writeHead(200,{"content-type":"text/html"});
    let data = fs.createReadStream("./about.html","utf8");
    data.pipe(res);
    }
    if(req.url=="/service"){
    //     res.write("This is My Service Page");
    //  res.end();
    res.writeHead(200,{"content-type":"text/html"});
    let data = fs.createReadStream("./service.html","utf8");
    data.pipe(res);
    }
    if(req.url=="/contact"){
    //     res.write("This is My Contact Page");
    //  res.end();
    res.writeHead(200,{"content-type":"text/html"});
    let data = fs.createReadStream("./contact.html","utf8");
    data.pipe(res);
    }
});


   
prompt.get(['userid', 'userpass'], function (err, result) {
    if(uid==result.userid && upass==result.userpass){
        server.listen(port,()=>{
            console.log(`Login User Is: ${user}`);
            console.log(`Server get started on ${host}:${port}`);
        })
    }else{
        console.log("Wrong Crendential, You Are Invalid User")
    }
  });