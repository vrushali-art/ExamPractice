class Product {
    // pid;
    // pname;
    // pprice;
    // pcompany

    constructor(id, name, price, company) {
        this.pid = id;
        this.pname = name;
        this.pprice = price;
        this.pcompany = company
    }
    productDetails() {
        console.log(`Id:${this.pid} Name:${this.pname} Price:${this.pprice} Company:${this.pcompany}`);
    }
}

module.exports = {
    Product
}