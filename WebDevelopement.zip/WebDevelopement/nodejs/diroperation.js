const fs = require('fs');

// how to delete file asynchronously
// fs.unlink("./deleteData.text",()=>{
//     console.log("file deleted successfully");
// });
// how to create directory asynchronously
// fs.mkdir("NewDir",()=>{
//     console.log("directory created successfully")
// })

// how to create directory with file asynchronously
// fs.mkdir("NewDirTwo",()=>{
//     console.log("directory created successfully")
//     fs.writeFile("./NewDirTwo/fileTwo.text","James Bond",()=>{
//         console.log("file created successfully")
//     })
// })

// how to delete derectory
// fs.rmdir("NewDir",()=>{
//     console.log("derectory deleted successfully");
// })

//how to remove directory containig file 
fs.unlink("./NewDirTwo/fileTwo.text",()=>{
    fs.rmdir("./NewDirTwo",()=>{
        console.log("directory and file deleted suucessfully ")
    })
})



