
const path = require('path');
const os = require('os');

console.log(__dirname);
console.log(__filename);
console.log(path.extname(__filename)); // it will return file extension
console.log(path.isAbsolute(__filename));
console.log(path.isAbsolute("../"+__filename))
console.log(path.join("../"+__filename))
console.log("=====================");
console.log(os.arch());
console.log(`Total Memory:${os.totalmem()}`);
console.log(`Free Memory:${os.freemem()}`);
console.log(`Free Home Dir :${os.homedir()}`);
console.log(`Free Host Name :${os.hostname()}`);
console.log(`Os Type  :${os.type()}`);
console.log(`Os Version  :${os.version()}`);
console.log(`Os machine  :${os.machine()}`);

