const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
    if (req.url == "/") {
        // res.write("This is My Home Page")
        // res.write("<html><body><h1>This is My Home Page</h1></body></html>")
        // res.end();
        let data = fs.createReadStream("./index.html","utf8");
         data.pipe(res);
    }else if(req.url=="/about"){
        // res.write("This is My About Page")
        res.write("<html><body><h1>This is My About Page</h1></body></html>")
        res.end();
    }else if(req.url=="/service"){
        // res.write("This is My Service Page")
        res.write("<html><body><h1>This is My Service Page</h1></body></html>")
        res.end();
    }
     if(req.url=="/contact"){
        // res.write("This is My Contact Page")
        // res.write("<html><body><h1>This is My Contact Page</h1></body></html>")
        // res.end();
        res.writeHead(200,{"content-type":"text/html"});
        let data = fs.createReadStream("./contact.html","utf8");
        data.pipe(res);
    }
});
server.listen(9999, () => {
    console.log("server get started")
})