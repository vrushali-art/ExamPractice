const express = require('express');
const app = express();


app.get("/product",(req,res,next)=>{
    res.send("this is simple get request for product");
});
app.post("/product",(req,res,next)=>{
    res.send("this is simple Post request for product");
});
app.put("/product",(req,res,next)=>{
    res.send("this is simple Put request for product");
});
app.delete("/product",(req,res,next)=>{
    res.send("this is simple Delete request for product");
});
app.get("/**",(req,res,next)=>{
    res.send("404......Page Not Found");
});
app.listen(8888,()=>{
    console.log("server get started");
})