
import samosa from '../../assets/images/samosa.jpg'
import dosa from '../../assets/images/dosa.jpg'
import vadapav from '../../assets/images/vadapav.jpg'
import bigImg from '../../assets/images/bigimg-2.jpg'
import vdo from '../../assets/Multimedia/video.mp4';
import ado from '../../assets/Multimedia/audio.mp3';

const data ={
    samosa,dosa,vadapav,bigImg,vdo,ado
}
export default data;