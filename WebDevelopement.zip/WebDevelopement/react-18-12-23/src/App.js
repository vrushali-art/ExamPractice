import logo from './logo.svg';
import './App.css';
import FuntionComp from './components/FunctionComp';
import Classcomp from './components/Classcomp';
import MyStateComp from './components/MyStateComp';
import HoverComp from './components/HoverComp';
import UpdateStateComp from './components/UpdateStateComp';
import CondRenderComp from './components/CondRenderComp';
import MyImagesComp from './components/MyImagesComp';
import MyCssComp from './components/MyCssComp';
import ParentComp from './components/ParentComp';

function App() {
  return (
    <div className="App">
      {/* <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header> */}
      <h1 className='text-primary bg-info text-center'>Welcome You All In My React Session</h1>
       
       {/* <FuntionComp myName="Panchashil Wankhede" post="Fullstact Developer" />
       <Classcomp myName="Sweta Wankhede" post="React Developer"/> */}
       {/* <MyStateComp /> */}
      {/* <HoverComp /> */}
      {/* <UpdateStateComp /> */}
      {/* <CondRenderComp /> */}
      {/* <MyImagesComp /> */}
      {/* <MyCssComp /> */}
      <ParentComp />

    </div>
  );
}

export default App;
