import samosa from '../assets/images/samosa.jpg';
import dosa from '../assets/images/dosa.jpg';
import vadapav from '../assets/images/vadapav.jpg';
import data from '../shared/constant/constantData';
import { Fragment } from 'react';

const MyImagesComp = () => {

    return (<Fragment>
        <h2>This is My Images Component</h2>
        <img src={samosa} alt='samosa' height="200px" />
        <img src={dosa} alt='dosa' height="200px" />
        <img src={vadapav} alt='vadapav' height="200px" />
        {/* access data from constant file  */}
        < hr />
        <img src={data.samosa} alt='samosa' height="200px" />
        <img src={data.dosa} alt='samosa' height="200px" />
        <img src={data.vadapav} alt='samosa' height="200px" />
        <br />
        <video controls src={data.vdo}></video>
    </Fragment>)
}
export default MyImagesComp;