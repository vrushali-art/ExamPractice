import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import MyImagesComp from './MyImagesComp';
import FavColorCom from './FavColorCom';
import UserFormComp from './UserFormComp';
import PageNotFound from './PageNotFound';
import Classcomp from './Classcomp';
import MyCssComp from './MyCssComp';
import MyStateComp from './MyStateComp';
import NavComp from './NavComp';
import ReactHooksComp from '../Hooks/ReactHooksComp';
import UseStateHookComp from '../Hooks/UseStateHookComp';
import UseEffectHookComp from '../Hooks/UseEffectHookComp';
import DashboardComp from '../CRUD/DashboardComp';
import AddProductComp from '../CRUD/AddProductComp';
import EditProductComp from '../CRUD/EditProductComp';
import MyCarouselComp from './MyCarouselComp';
import LoginComp from './LoginComp';
const MyRoutingComp = () => {
    return (
        <div className='container'>
            <BrowserRouter>
                <div className='card border-primary'>
                    <div className='card-header border-primary'>
                        <NavComp />
                    </div>
                    <div className='card-body border-primary'>
                        <Routes>
                            {/* default routing  */}
                            <Route path="" element={<LoginComp />}></Route>
                            <Route path="login" element={<LoginComp />}></Route>
                            {/* <Route path='' element={<MyImagesComp />}></Route> */}
                            {/* naming routing  */}
                            <Route path='multimedia' element={<MyImagesComp />}></Route>
                            <Route path='list' element={<FavColorCom />}></Route>
                            {/* parameterize routing  */}
                            <Route path='frm/:id' element={<UserFormComp />}></Route>
                            <Route path='frm' element={<UserFormComp />}></Route>
                            <Route path="carosel" element={<MyCarouselComp />}></Route>
                             {/* child routing  */}
                             <Route path='classcomp' element={<Classcomp />}>
                                <Route path='mycss' element={<MyCssComp />}></Route>
                                <Route path='mystatecomp' element={<MyStateComp />}></Route>
                             </Route>
                             {/* routing for react hooks  */}
                             <Route path="hooks" element={<ReactHooksComp />}>
                                <Route path='' element={<UseStateHookComp />}></Route>
                                <Route path='usestate' element={<UseStateHookComp />}></Route>
                                <Route path='useeffect' element={<UseEffectHookComp />}></Route>
                             </Route>
                             {/* routing for crud operation  */}
                             <Route path="dashboard" element={<DashboardComp />}></Route>
                             <Route path='addproduct' element={<AddProductComp />}></Route>
                             <Route path="editproduct/:id" element={<EditProductComp />}></Route>
                            {/* wildcard routing  */}
                            <Route path='/*' element={<PageNotFound />}></Route>
                        </Routes>
                    </div>
                    <div className='card-footer border-primary'>
                        <div className='text-primary' style={{float:"right"}}>
                            This App Is Design And Developed By 
                            <strong>Panchashil Wankhede</strong> <sup>&copy;</sup>  
                        </div>
                    </div>
                </div>
            </BrowserRouter>
        </div>
    )
}

export default MyRoutingComp
