import React from 'react'
import { Link } from 'react-router-dom';

const NavComp = () => {
    return (
        <div>
            {/* <h2>This is Nav Component</h2> */}
            <Link to="/carosel" className='btn btn-outline-primary btn-sm'>Carosuel</Link>{" "}
            <Link to="/multimedia" className='btn btn-outline-primary btn-sm'>Multimedia</Link>{" "}
            <Link to="/list" className='btn btn-outline-primary btn-sm'>FavColor</Link>{" "}
            <Link to="/frm" className='btn btn-outline-primary btn-sm'>Form</Link>{" "}
            <Link to="/classcomp" className='btn btn-outline-primary btn-sm'>ClassComp</Link>{" "}
            <Link to="/hooks" className='btn btn-outline-warning btn-sm'>Hooks</Link>{" "}
            <Link to="/dashboard" className='btn btn-outline-success btn-sm'>CRUD</Link>{" "}
        </div>
    )
}

export default NavComp
