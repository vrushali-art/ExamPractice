import React from 'react'
import  {Button,Carousel} from 'react-bootstrap';
import data from '../shared/constant/constantData';

const MyCarouselComp = () => {
    return (
        <div>
            <h2>This is myCorosoul component</h2>
            <Button>React button</Button>{" "}
            <Button variant='success'>React button</Button>
            <hr />
    
            <Carousel>
      <Carousel.Item>
        {/* <ExampleCarouselImage text="First slide" /> */}
        <img src={data.samosa} alt="" style={{width:"100%",height:"300px"}} />
        <Carousel.Caption>
          <h3>First slide label</h3>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        {/* <ExampleCarouselImage text="Second slide" /> */}
        <img src={data.dosa} alt="" style={{width:"100%",height:"300px"}} />
        <Carousel.Caption>
          <h3>Second slide label</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        {/* <ExampleCarouselImage text="Third slide" /> */}
        <img src={data.vadapav} alt=""  style={{width:"100%",height:"300px"}}/>
        <Carousel.Caption>
          <h3>Third slide label</h3>
          <p>
            Praesent commodo cursus magna, vel scelerisque nisl consectetur.
          </p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>


        </div>
    )
}

export default MyCarouselComp
