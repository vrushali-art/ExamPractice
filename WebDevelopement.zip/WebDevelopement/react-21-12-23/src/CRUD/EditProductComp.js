import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useParams ,useNavigate} from 'react-router-dom';

const EditProductComp = () => {
    const nav = useNavigate();
    const {id} = useParams(); 
    const [item,setItem] = useState({
        id:"",
        name:"",
        price:"",
        company:""
    })
    useEffect(()=>{
        axios.get(`http://localhost:8888/product/${id}`).then((res)=>{
            // console.log(res.data);
            setItem(res.data)
        }).catch((err)=>{})
    },[])

    const addProduct = (event)=>{
        event.preventDefault();
        console.log(item);
        axios.put(`http://localhost:8888/product/${id}`,item).then(()=>{
            window.alert("Product Updated Successfully");
            nav("/dashboard");
        }).catch((err)=>{})
    }

    const inputChangeHandler = (event)=>{
        const {type,name,value} = event.target;
        setItem({...item,[name]:value});
  }
    return (
        <div>
            <h2>This is Edit Product Component</h2>
            <form onSubmit={addProduct} style={{width:"400px"}}>
                <div className='form-group'>
                    <label className='form-label'>Enter Product Name:</label>
                    <input type='text' name="name" className='form-control' onChange={inputChangeHandler} value={item.name}/>
                </div>
                <div className='form-group'>
                    <label className='form-label'>Enter Product Price:</label>
                    <input type='text' name="price" className='form-control' onChange={inputChangeHandler} value={item.price} />
                </div>
                <div className='form-group'>
                    <label className='form-label'>Enter Product Compnay:</label>
                    <input type='text' name="company" className='form-control' onChange={inputChangeHandler} value={item.company} />
                </div>
               <button type='submit' className='btn btn-primary mt-2'>submit</button>
            </form>
        </div>
    )
}

export default EditProductComp
