import axios from 'axios';
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

const AddProductComp = () => {
    const nav = useNavigate();
    
   const [item,setItem] = useState({
    name:"",
    price:"",
    company:""
   });

const inputChangeHandler = (event)=>{
      const {type,name,value} = event.target;
      setItem({...item,[name]:value});
}
//this is add request
const addProduct = (event)=>{
    event.preventDefault();
    console.log(item);
    axios.post("http://localhost:8888/product",item).then(()=>{
        window.alert("Product Added Successfully");
        nav("/dashboard");
    }).catch((err)=>{})
}
    return (
        <div>
            <h2>This Is Add Product Component</h2>
            <form onSubmit={addProduct} style={{width:"400px"}}>
                <div className='form-group'>
                    <label className='form-label'>Enter Product Name:</label>
                    <input type='text' name="name" className='form-control' onChange={inputChangeHandler} value={item.name}/>
                </div>
                <div className='form-group'>
                    <label className='form-label'>Enter Product Price:</label>
                    <input type='text' name="price" className='form-control' onChange={inputChangeHandler} value={item.price} />
                </div>
                <div className='form-group'>
                    <label className='form-label'>Enter Product Compnay:</label>
                    <input type='text' name="company" className='form-control' onChange={inputChangeHandler} value={item.company} />
                </div>
               <button type='submit' className='btn btn-primary mt-2'>submit</button>
            </form>
        </div>
    )
}

export default AddProductComp
