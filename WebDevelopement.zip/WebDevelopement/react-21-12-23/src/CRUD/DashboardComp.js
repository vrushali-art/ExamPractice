import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import { Button,Modal } from 'react-bootstrap';

const DashboardComp = () => {
    const [product,setProduct] = useState([]);
    const [item,setItem] = useState({});
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = (data) => {
        setItem(data)
        setShow(true)
    };

    useEffect(()=>{
        fetchData();
    },[]);
    

    // this get request 
    const fetchData = ()=>{
        axios.get("http://localhost:8888/product").then((res)=>{
            console.log(res.data);
            setProduct(res.data);
        }).catch((err)=>{})
    }
  // this is delete request 
  const  deleteRecord = (id)=>{
      if(window.confirm(`Are You Sure To Delete Record With Id: ${id} `)){
        axios.delete(`http://localhost:8888/product/${id}`).then(()=>{
            window.alert("Product deleted Successfully");
            fetchData();
           }).catch((err)=>{})
      }
    }
    return (
        <div>
           <h2>This is Dashboard component</h2> 
           <Link to="/addproduct" className='btn btn-primary mb-1 mt-2'> 
           <i class="fa fa-plus" aria-hidden="true"></i> Add 
           </Link>
           <table className='table table-hover table-striped'>  
               <thead>
                <tr className='table-dark'>
                    <th>Sr.No</th> <th>Name</th><th>Price</th><th>Company</th><th>Action</th>
                </tr>
               </thead>
               <tbody>
                 { product.map((val,index)=>{
                    return <tr key={index}>
                        <td>{index+1}</td>
                        <td>{val.name}</td>
                        <td>{val.price}</td>
                        <td>{val.company}</td>
                        <td>
                            <Button variant='outline-primary'  onClick={()=>handleShow(val)} >
                                <i class="fa fa-eye" aria-hidden="true"></i>
                            </Button> | 
                            <Link to={`/editproduct/${val.id}`} className='btn btn-outline-success btn-sm'>
                            <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                            </Link> | 
                            <button type='button' className='btn btn-outline-danger btn-sm' onClick={()=>deleteRecord(val.id)}>
                            <i class="fa fa-trash-o" aria-hidden="true"></i>
                            </button>
                        </td>
                    </tr>
                 })}
               </tbody>
           </table>
           {/* model start here  */}
           <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>{item.name}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
         <table>
            <tr><th>Id:</th><th>{item.id}</th></tr>
            <tr><th>Name:</th><th>{item.name}</th></tr>
            <tr><th>Price:</th><th>{item.price}</th></tr>
            <tr><th>Company:</th><th>{item.company}</th></tr>
         </table>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          {/* <Button variant="primary">Understood</Button> */}
        </Modal.Footer>
      </Modal>
        </div>
    )
}

export default DashboardComp
