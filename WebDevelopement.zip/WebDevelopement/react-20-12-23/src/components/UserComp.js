import React from 'react'

const UserComp = (props) => {
    // return (
    //     <div>
    //         <h3>{props.uname} login Successfully</h3>
    //     </div>
    // )

    if(props.uname==="Aadesh"){
        //    return "not a user"
        throw new Error("not a user");
    }
    return <h3>{props.uname} login Successfully</h3>
   
}

export default UserComp
