import React, { Component } from 'react'

class LifeCycleComp extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             color:"red"
        }
    }
    // static getDerivedStateFromProps(props){
    //     return{
    //         color:props.mycolor
    //     }
    // }
     
    // componentDidMount(){
    //     setTimeout(()=>{
    //         this.setState({color:"Blue"});
    //     },2000)
    // }
    shouldComponentUpdate(){
        return true;
    }
    changeColor = ()=>{
        this.setState({color:"Pink"})
    }
    getSnapshotBeforeUpdate(prevprops,prevState){
      document.getElementById("beforeupdate").innerHTML = `My Favourite color was Before Upadte: ${prevState.color} `;
    }
    componentDidUpdate(){
        document.getElementById("afterupdate").innerHTML = `My Favourite color After Upadte is: ${this.state.color} `;
    }
    render() {
        return (
            <div>
                <h2>This is Component Lifecycle Component</h2>
                <p>You Have Selected <strong>{this.state.color}</strong>  color</p>
                
                <div id='beforeupdate'></div>
                <div id='afterupdate'></div>
                <button type='button' onClick={this.changeColor} className='btn btn-info mt-2'>change color </button>
            </div>
        )
    }
}

export default LifeCycleComp
