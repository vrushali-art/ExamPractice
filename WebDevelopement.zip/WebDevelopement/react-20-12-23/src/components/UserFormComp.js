import React, { Component } from 'react'
import './external.css';
class UserFormComp extends Component {
    uCourse = ["Angular", "React", "Java", "Python", "Nodejs"];
    constructor(props) {
        super(props)

        this.state = {
            fname: "",
            courses:""
        }
    }
    inputChangeHandler = (event) => {
        // console.log(event.target.type)
        // console.log(event.target.name)
        // console.log(event.target.value)
        const { type, name, value } = event.target;
        this.setState({ [name]: value })
    }
    chekData = (event) => {
        event.preventDefault();
        if (this.state.fname === "") {
            window.alert("Full name is required");
            return false;
        }
        if (!this.state.fname.match("^[a-zA-Z ]{3,20}$")) {
            window.alert("Full name must contain only character min-3 and max-20");
            return false;
        }
        if (this.state.courses === "") {
            window.alert("Please Select Your Course");
            return false;
        }
        window.alert(JSON.stringify(this.state))
    }
    render() {
        const { fname, courses } = this.state;
        return (
            <div>

                <div className='container text-center'>
                    <h2>This is User Form Component</h2>
                    <form className='myform' onSubmit={this.chekData}>
                        <div className='form-group'>
                            <label className='form-label'>Enter Your FullName:</label>
                            <input type='text' name='fname' className='form-control' onChange={this.inputChangeHandler} value={fname} />
                        </div>
                        <div className='form-group'>
                        <label className='form-label'>Select Your Course:</label>
                        <select name='courses' className='form-control'  onChange={this.inputChangeHandler} >
                           <option value="">Select Your Course</option>
                           {
                            this.uCourse.map((val,index)=>{
                                return <option value={val} key={index}>{val}</option>
                            })
                           }
                        </select>
                        </div>

                        <button type='submit' className='btn btn-success mt-2'>Submit</button>
                    </form>
                </div>
            </div>
        )
    }
}

export default UserFormComp
