import React from 'react'

const PageNotFound = () => {
    return (
        <div>
            <h2 style={{color:"red",textAlign:"center"}}>404.......Page not Found</h2>
           <p style={{color:"green",textAlign:"center"}}>try another routing....</p>
        </div>
    )
}

export default PageNotFound
