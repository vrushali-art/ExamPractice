import React, { Component } from 'react'

class FavColorCom extends Component {
    constructor(props) {
        super(props)

        this.state = {
            colors: [
                { id: 101, name: "Red" },
                { id: 102, name: "Green" },
                { id: 103, name: "Blue" },
                { id: 104, name: "Pink" }
            ]
        }
    }

    render() {
        const {colors} = this.state;
        return (
            <div>
                <h2>This is Favourite Color Component</h2>
                <ul>
                  
                  { colors.length > 0 && colors.map((val,index)=>{
                    // return <li key={val.id}>{val.name}</li>
                    return <li key={index}>{val.name}</li>
                  })}
                </ul>
            </div>
        )
    }
}

export default FavColorCom
