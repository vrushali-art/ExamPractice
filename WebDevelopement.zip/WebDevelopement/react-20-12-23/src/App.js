import logo from './logo.svg';
import './App.css';
import FuntionComp from './components/FunctionComp';
import Classcomp from './components/Classcomp';
import MyStateComp from './components/MyStateComp';
import HoverComp from './components/HoverComp';
import UpdateStateComp from './components/UpdateStateComp';
import CondRenderComp from './components/CondRenderComp';
import MyImagesComp from './components/MyImagesComp';
import MyCssComp from './components/MyCssComp';
import ParentComp from './components/ParentComp';
import HoverCounterComp from './components/HoverCounterComp';
import ClickCounterComp from './components/ClickCounterComp';
import RenderPropsComp from './components/RenderPropsComp';
import FavColorCom from './components/FavColorCom';
import UserFormComp from './components/UserFormComp';
import UserComp from './components/UserComp';
import ErrorBoundary from './components/ErrorBoundary';
import LifeCycleComp from './components/LifeCycleComp';
import MyRoutingComp from './components/MyRoutingComp';

function App() {
  return (
    <div className="App">
      {/* <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header> */}
      <h1 className='text-primary bg-info text-center'>Welcome You All In My React Session</h1>
       
       {/* <FuntionComp myName="Panchashil Wankhede" post="Fullstact Developer" />
       <Classcomp myName="Sweta Wankhede" post="React Developer"/> */}
       {/* <MyStateComp /> */}
      {/* <HoverComp />
      <UpdateStateComp /> */}
      {/* <CondRenderComp /> */}
      {/* <MyImagesComp />
      <MyCssComp /> */}
      {/* <ParentComp /> */}
      {/* <HoverCounterComp />
      <ClickCounterComp /> */}
      {/* <RenderPropsComp render={(isLogin)=>{return isLogin ?"Panchashil" :"User"}} /> */}
      {/* <RenderPropsComp render = {(count,incrementCount)=>{return <ClickCounterComp count={count} incrementCount={incrementCount} />}} />
      <RenderPropsComp render = {(count,incrementCount)=>{return <HoverCounterComp count={count} incrementCount={incrementCount} />}} /> */}
     {/* <FavColorCom /> */}
     {/* <UserFormComp /> */}
     {/* <ErrorBoundary>
        <UserComp uname="Panchashil" />
     </ErrorBoundary>
    
     <ErrorBoundary>
        <UserComp uname ="Aadesh" />
     </ErrorBoundary>
     <ErrorBoundary>
        <UserComp uname="Anmol" />
     </ErrorBoundary>
     <ErrorBoundary>
        <UserComp uname="Rahul" />
     </ErrorBoundary> */}
     {/* <LifeCycleComp mycolor="green" /> */}
     <MyRoutingComp />
    </div>
  );
}

export default App;
