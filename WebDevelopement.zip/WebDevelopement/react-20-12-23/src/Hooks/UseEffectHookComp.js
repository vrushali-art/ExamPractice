import React, { useEffect, useState } from 'react'

const UseEffectHookComp = () => {
    const [count, setCount] = useState(0);
    const [sal, setSal] = useState(10000);
    //1.with no dependency 
    // useEffect(()=>{
    //     setCount(count+1)
    // })

    //2. using dependency as blank array  => it execute only once
    // useEffect(()=>{
    //     setCount(count+1)
    // },[])
    const incrementSalary = () => {
        setSal(sal + 1000);
    }

    // 3. execute useEffect when dependency value change 
    useEffect(() => {
        setCount(count + 1)
    }, [sal]);
    return (
        <div>
            <h2>This is useEffect hook component</h2>
            <p>Counter value is: <strong>{count}</strong> </p>
            <p>My Salary is: <strong>{sal}</strong> </p>
            <button type='button' onClick={incrementSalary} >increment salary</button>
        </div>
    )
}

export default UseEffectHookComp
