import React, { useState } from 'react'

const UseStateHookComp = () => {
   const [count,setCount]= useState(0);
   const [myName,setMyname] = useState("Panchashil");
  const [fruits,setFruits] = useState(["Apple","Graps","Banana","Mango","Chiku"])
   const incrementCounter = ()=>{
       setCount(count+1);
   }
    return (
        <div>
            <h2>This is usestate hook component</h2>
            <p>Count value is : <strong>{count}</strong></p>
            <p>My Name is : <strong>{myName}</strong></p>
            {/* <button type='button' onClick={incrementCounter}>counter++</button> */}
            <button type='button' onClick={()=>setCount(count+1)}>counter++</button>
            <button type='button' onClick={()=>setMyname("Panchashil Wankhede")}>change name</button>

            <ul>
                { fruits.map((val,index)=>{
                    return <li key={index}>{val}</li>
                })}
            </ul>
        
        </div>
    )
}

export default UseStateHookComp
