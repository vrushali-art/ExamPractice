import axios from 'axios';
import React, { useEffect, useState } from 'react'

const DashboardComp = () => {
    const [product,setProduct] = useState([]);

    useEffect(()=>{
        fetchData();
    },[]);
    
    const fetchData = ()=>{
        axios.get("http://localhost:8888/product").then((res)=>{
            console.log(res.data);
            setProduct(res.data);
        }).catch((err)=>{})
    }

    return (
        <div>
           <h2>This is Dashboard component</h2> 
           <table className='table table-hover table-striped'>
               <thead>
                <tr className='table-dark'>
                    <th>Sr.No</th> <th>Name</th><th>Price</th><th>Company</th>
                </tr>
               </thead>
               <tbody>
                 { product.map((val,index)=>{
                    return <tr key={index}>
                        <td>{index+1}</td>
                        <td>{val.name}</td>
                        <td>{val.price}</td>
                        <td>{val.company}</td>
                       
                    </tr>
                 })}
               </tbody>
           </table>
        </div>
    )
}

export default DashboardComp
