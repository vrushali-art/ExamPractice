
class Students {
    // data-member
    stdId = 101;
    stdName = "Sammedh";
    stdAddress = "Pune";
    // use of constructor 
  constructor(id,name,addr){
    this.stdId = id;
    this.stdName = name;
    this.stdAddress = addr;
  }
    // member-function 
    details() {
        return `Id:${this.stdId} Name:${this.stdName} Address:${this.stdAddress}`;
    }
}
// how to create clas object 
//  let stdObj = new Students(201,"Rishikesh","Mumbai");
//  console.log(stdObj.details());
// console.log(stdObj.stdName);
// let stdObj1 = new Students(501,"Rashmika","Banglore");
//  console.log(stdObj1.details());
//  let stdObj2 = new Students(777,"JamsBond","UsA");
//  console.log(stdObj2.details());
 
class Result extends Students{
    phy;
    chem;
    math;
   constructor(id,name,addr,p,c,m){
    super(id,name,addr);
    this.phy = p;
    this.chem = c;
    this.math = m; 
   }
    total(){
        return this.phy+this.chem+this.math;
    }
    details(){
        return `Id:${this.stdId} Name:${this.stdName} Address:${this.stdAddress} Maks:${this.total()}`
    }

}
let resultObj =new Result(801,"Boby","Haryana",88,86,50)
console.log(resultObj.details());





