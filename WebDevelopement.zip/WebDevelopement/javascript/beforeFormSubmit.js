
function checkAll() {
    // window.alert("hi");
    let user = document.getElementById("uid").value;
    let regEmail = "^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$";
    if (user === "") {
        // window.alert("user id is requied");
        document.getElementById("uidErr").innerHTML ="user id is requied";
        document.getElementById("uidErr").style.color="red";
        return false;
    }else if(!user.match(regEmail)){
        document.getElementById("uidErr").innerHTML ="user id must be in properformate";
        document.getElementById("uidErr").style.color="red";
        return false;
    }else{
        document.getElementById("uidErr").innerHTML ="valid User Id";
        document.getElementById("uidErr").style.color="green"; 
        return false;
    }
}