// import {Product} from './product.mjs';
import Product from './product.mjs';

let productObj = new Product(201, "Laptop", 55000);
console.log(productObj.productDetails());

let productObj2 = new Product(202, "Mobile", 30000);
console.log(productObj2.productDetails());