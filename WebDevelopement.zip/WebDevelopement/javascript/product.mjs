
// export class Product {
class Product {

    pId;
    pName;
    pPrice;
    constructor(id, name, price) {
        this.pId = id;
        this.pName = name;
        this.pPrice = price;
    }

    productDetails() {
        return `ProductId:${this.pId} Name:${this.pName} Price:${this.pPrice}`
    }
}

// let productObj = new Product(201, "Laptop", 55000);
// console.log(productObj.productDetails());

export default Product;

