
function checkAll(){
   
//  var uname = document.getElementById("fname").value;
var uname = document.myform.fname.value;
 var regname = "^[a-zA-Z ]{5,20}$";

 var uedu = document.myform.edu;

 var ucourse = document.myform.course.value;
 if(uname===""){
   window.alert("This field is required");
   document.getElementById("fname").focus();
   return false;
 }
 if(!uname.match(regname)){
    window.alert("FullName must contain only character min-5 and max-20");
    document.getElementById("fname").focus();
    return false;
 }
 if(uedu[0].checked==false && uedu[1].checked==false && uedu[2].checked==false && uedu[3].checked==false){
    window.alert("Please select Your Qualification");
    document.getElementById("fname").focus();
    return false;
 }
 if(ucourse===""){
    window.alert("This field is required");
    document.getElementById("course").focus();
    return false;
  }
}