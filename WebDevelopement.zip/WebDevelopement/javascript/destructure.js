
let fruits = ["Apple","Banana","Mango","Graps"];

// let fruits1 = fruits[0];
// let fruits2 = fruits[1];
// let fruits3 = fruits[2];
// console.log(fruits1,fruits2,fruits3);

// destructuring of array
const [frt1,frt2,frt3,frt4] = fruits;
console.log(frt1,frt2,frt3,frt4);

let emp = {id:101,name:"Anshul",post:"Manager"};
// let empId = emp.id;
// let empName = emp.name;
// let empPost = emp.post;
// console.log(empId,empName,empPost);

// destruring object
const {id,name,post} = emp;
console.log(`Id:${id} Name:${name} Post:${post}`);

